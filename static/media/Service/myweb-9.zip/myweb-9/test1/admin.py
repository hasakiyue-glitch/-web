from django.contrib import admin
from .models import pic

# Register your models here.
class picAdmin(admin.ModelAdmin):
    list_display=['description','photo']
admin.site.register(pic,picAdmin)
admin.site.site_header="人工智能学院"
admin.site.site_title="人工智能学院"